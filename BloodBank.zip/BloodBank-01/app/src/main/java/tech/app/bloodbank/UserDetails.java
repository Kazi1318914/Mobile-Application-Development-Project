package tech.app.bloodbank;

public class UserDetails {
    static String fName, lName, phoneNo, bloodGroup, address, dob;

    UserDetails(){}

}
